import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { 
  Home, 
  Box, 
  Image,
  Video, 
  Sparkles, 
  Store, 
  Lightbulb,
  GraduationCap,
  Users,
  Search,
  Wand,
  Bell,
  ShoppingCart,
  Star,
  Heart,
  MessageCircle,
  MoreHorizontal,
  Zap,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import GeneratePage from './pages/GeneratePage';

// Navigation items
const navItems = [
  { icon: Home, label: 'Home', active: true },
  { icon: Box, label: 'Models' },
  { icon: Image, label: 'AI Image' },
  { icon: Video, label: 'AI Video' },
  { icon: Sparkles, label: 'Workflow' },
];

const secondaryNav = [
  { icon: Store, label: 'Events' },
  { icon: Lightbulb, label: 'Inspiration' },
  { icon: ShoppingCart, label: 'AI Shops' },
  { icon: GraduationCap, label: 'Creator Academy' },
  { icon: Users, label: 'Profile' },
];

// Feature cards data
const featureCards = [
  {
    title: 'Image Generation',
    subtitle: 'Intelligent Drawing, Instant Artistry',
    image: '/feature-image-gen.jpg',
    gradient: 'from-emerald-500/20 to-teal-500/20'
  },
  {
    title: 'Video Generation',
    subtitle: 'Creative Vision, One-Click Creation',
    image: '/feature-video-gen.jpg',
    gradient: 'from-amber-500/20 to-orange-500/20'
  },
  {
    title: 'AI Characters',
    subtitle: 'Virtual Bond, Real Connection',
    image: '/feature-ai-char.jpg',
    gradient: 'from-emerald-500/20 to-cyan-500/20'
  }
];

// AI Models data
const aiModels = [
  { id: 1, name: 'SonoVision Pro', type: 'AI Model', rating: 4.8, image: '/model-1.jpg', badge: 'Checkpoint', free: true },
  { id: 2, name: 'Nano Banana XL', type: 'AI App', rating: 4.6, image: '/model-2.jpg', badge: 'APP', free: true },
  { id: 3, name: 'Opera Master', type: 'AI Model', rating: 5.0, image: '/model-3.jpg', badge: 'Checkpoint', free: false },
  { id: 4, name: 'Waltz 2.6', type: 'AI Model', rating: 4.7, image: '/model-4.jpg', badge: 'Checkpoint', free: true },
  { id: 5, name: 'CyberPunk V', type: 'AI Model', rating: 4.9, image: '/model-5.jpg', badge: 'Checkpoint', free: false },
];

// Gallery data
const galleryItems = [
  { id: 1, title: 'Sky Castle', author: 'Alisa', likes: 867, comments: 73, image: '/gallery-1.jpg' },
  { id: 2, title: 'Royal Treatment', author: 'Kaylen', likes: 416, comments: 38, image: '/gallery-2.jpg' },
  { id: 3, title: 'Neon Dreams', author: 'Noir8', likes: 551, comments: 54, image: '/gallery-3.jpg' },
  { id: 4, title: 'City Reflections', author: 'Griff', likes: 208, comments: 27, image: '/gallery-4.jpg' },
  { id: 5, title: 'Piano Melody', author: 'TRICK', likes: 390, comments: 37, image: '/model-1.jpg' },
  { id: 6, title: 'Sunflower Girl', author: 'minase', likes: 464, comments: 59, image: '/model-2.jpg' },
  { id: 7, title: 'Opera Night', author: 'momokuma', likes: 255, comments: 33, image: '/model-3.jpg' },
  { id: 8, title: 'Cyber Rebel', author: 'Passion', likes: 380, comments: 41, image: '/model-5.jpg' },
];

function Sidebar() {
  return (
    <aside className="fixed left-0 top-0 w-60 h-full bg-[#0D0F0E] border-r border-white/5 z-50 flex flex-col">
      {/* Logo */}
      <div className="p-4 flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-gradient-emerald flex items-center justify-center">
          <Sparkles className="w-5 h-5 text-white" />
        </div>
        <span className="text-lg font-bold text-white">AI Nexus</span>
      </div>

      <ScrollArea className="flex-1 px-3">
        {/* Primary Navigation */}
        <nav className="space-y-1">
          {navItems.map((item) => (
            <a
              key={item.label}
              href="#"
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200 group ${
                item.active 
                  ? 'bg-white/5 text-white border-l-2 border-emerald-500' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className={`w-4 h-4 ${item.active ? 'text-emerald-400' : 'group-hover:text-emerald-400'}`} />
              <span className="flex-1">{item.label}</span>

            </a>
          ))}
        </nav>

        {/* Divider */}
        <div className="my-4 border-t border-white/5" />

        {/* Secondary Navigation */}
        <nav className="space-y-1">
          {secondaryNav.map((item) => (
            <a
              key={item.label}
              href="#"
              className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-white/5 transition-all duration-200 group"
            >
              <item.icon className="w-4 h-4 group-hover:text-emerald-400" />
              <span>{item.label}</span>
            </a>
          ))}
        </nav>

        {/* More Button */}
        <button className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-gray-400 hover:text-white hover:bg-white/5 transition-all duration-200 w-full mt-2">
          <MoreHorizontal className="w-4 h-4" />
          <span>More</span>
        </button>
      </ScrollArea>

      {/* Footer */}
      <div className="p-4 border-t border-white/5">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white text-xs font-bold">
            U
          </div>
          <div className="flex-1">
            <p className="text-sm text-white font-medium">User</p>
            <p className="text-xs text-gray-500">Free Plan</p>
          </div>
        </div>
        <div className="flex gap-2 text-gray-500">
          <a href="#" className="text-xs hover:text-emerald-400 transition-colors">Privacy</a>
          <span className="text-xs">·</span>
          <a href="#" className="text-xs hover:text-emerald-400 transition-colors">Terms</a>
        </div>
      </div>
    </aside>
  );
}

function Header() {
  const navigate = useNavigate();
  
  return (
    <header className="fixed top-0 left-60 right-0 h-16 glass-effect border-b border-white/5 z-40 px-6 flex items-center justify-between">
      {/* Search Bar */}
      <div className="flex-1 max-w-2xl">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <Input 
            placeholder="Search models, creators, styles..."
            className="w-full pl-11 pr-24 py-2.5 bg-[#141816] border-white/10 rounded-full text-sm text-white placeholder:text-gray-500 focus:border-emerald-500/50 focus:ring-emerald-500/20"
          />
          <Button 
            size="sm" 
            className="absolute right-1.5 top-1/2 -translate-y-1/2 bg-white/10 hover:bg-white/15 text-gray-300 rounded-full text-xs px-3 h-7"
          >
            <Zap className="w-3 h-3 mr-1" />
            AI Search
          </Button>
        </div>
      </div>

      {/* Actions */}
      <div className="flex items-center gap-3">
        <Button 
          onClick={() => navigate('/generate')}
          className="bg-gradient-emerald hover:opacity-90 text-white rounded-full px-5 gap-2"
        >
          <Wand className="w-4 h-4" />
          Create
        </Button>
        <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white hover:bg-white/5 relative">
          <ShoppingCart className="w-5 h-5" />
        </Button>
        <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white hover:bg-white/5 relative">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1 right-1 w-2 h-2 bg-emerald-500 rounded-full" />
        </Button>
        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white text-sm font-bold cursor-pointer">
          U
        </div>
      </div>
    </header>
  );
}

function FeatureCard({ card }: { card: typeof featureCards[0] }) {
  return (
    <div className="relative group cursor-pointer overflow-hidden rounded-2xl bg-[#1A1E1C] border border-white/5 card-hover">
      <div className="absolute inset-0">
        <img src={card.image} alt={card.title} className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity duration-300" />
        <div className={`absolute inset-0 bg-gradient-to-t ${card.gradient} opacity-40`} />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D0F0E] via-transparent to-transparent" />
      </div>
      <div className="relative p-5 h-40 flex flex-col justify-end">
        <h3 className="text-white font-semibold text-lg mb-1">{card.title}</h3>
        <p className="text-gray-400 text-xs">{card.subtitle}</p>
      </div>
    </div>
  );
}

function ModelCard({ model }: { model: typeof aiModels[0] }) {
  return (
    <div className="group cursor-pointer">
      <div className="relative overflow-hidden rounded-xl bg-[#141816] border border-white/5 card-hover">
        <div className="aspect-[3/4] relative">
          <img src={model.image} alt={model.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D0F0E] via-transparent to-transparent opacity-80" />
          
          {/* Badge */}
          <Badge className="absolute top-2 left-2 bg-black/60 text-gray-300 text-[10px] border-0 backdrop-blur-sm">
            {model.badge}
          </Badge>
          
          {/* FREE Badge */}
          {model.free && (
            <Badge className="absolute top-2 right-2 bg-gradient-amber text-white text-[10px] border-0 font-bold">
              FREE
            </Badge>
          )}
          
          {/* Info */}
          <div className="absolute bottom-0 left-0 right-0 p-3">
            <h4 className="text-white font-medium text-sm truncate mb-1">{model.name}</h4>
            <div className="flex items-center justify-between">
              <span className="text-gray-500 text-xs">{model.type}</span>
              <div className="flex items-center gap-1">
                <Star className="w-3 h-3 text-amber-400 fill-amber-400" />
                <span className="text-amber-400 text-xs font-medium">{model.rating}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function GalleryCard({ item }: { item: typeof galleryItems[0] }) {
  return (
    <div className="group cursor-pointer">
      <div className="relative overflow-hidden rounded-xl bg-[#141816] border border-white/5 card-hover">
        <div className="aspect-auto relative">
          <img src={item.image} alt={item.title} className="w-full h-auto object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D0F0E]/90 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Hover Info */}
          <div className="absolute bottom-0 left-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <h4 className="text-white font-medium text-sm mb-2">{item.title}</h4>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white text-[10px] font-bold">
                  {item.author[0]}
                </div>
                <span className="text-gray-400 text-xs">{item.author}</span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1">
                  <Heart className="w-3 h-3 text-gray-400" />
                  <span className="text-gray-400 text-xs">{item.likes}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MessageCircle className="w-3 h-3 text-gray-400" />
                  <span className="text-gray-400 text-xs">{item.comments}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SectionHeader({ title, icon: Icon, action }: { title: string; icon?: React.ElementType; action?: string }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <div className="flex items-center gap-2">
        {Icon && <Icon className="w-5 h-5 text-emerald-400" />}
        <h2 className="text-white font-semibold text-lg">{title}</h2>
      </div>
      {action && (
        <a href="#" className="flex items-center gap-1 text-gray-400 hover:text-emerald-400 text-sm transition-colors">
          {action}
          <ChevronRight className="w-4 h-4" />
        </a>
      )}
    </div>
  );
}

function HomePage() {
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
  }, []);

  return (
    <div className="min-h-screen bg-[#0D0F0E]">
      <Sidebar />
      <Header />
      
      <main className="ml-60 pt-16 min-h-screen">
        <div className={`p-6 transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
          {/* Feature Cards */}
          <section className="mb-8">
            <div className="grid grid-cols-3 gap-4">
              {featureCards.map((card, index) => (
                <div key={card.title} className="animate-fade-in-up" style={{ animationDelay: `${index * 0.1}s` }}>
                  <FeatureCard card={card} />
                </div>
              ))}
            </div>
          </section>

          {/* AI Models Section */}
          <section className="mb-8">
            <SectionHeader 
              title="Featured AI Models" 
              icon={Sparkles}
              action="View All"
            />
            <div className="grid grid-cols-5 gap-4">
              {aiModels.map((model, index) => (
                <div key={model.id} className="animate-fade-in-up" style={{ animationDelay: `${index * 0.05}s` }}>
                  <ModelCard model={model} />
                </div>
              ))}
            </div>
          </section>

          {/* Explore Gallery Section */}
          <section className="mb-8">
            <SectionHeader 
              title="Explore Community Creations" 
              icon={Lightbulb}
            />
            <div className="columns-4 gap-4 space-y-4">
              {galleryItems.map((item, index) => (
                <div key={item.id} className="animate-fade-in-up break-inside-avoid" style={{ animationDelay: `${index * 0.05}s` }}>
                  <GalleryCard item={item} />
                </div>
              ))}
            </div>
          </section>

          {/* Footer */}
          <footer className="mt-12 pt-8 border-t border-white/5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-emerald-400" />
                <span className="text-white font-semibold">AI Nexus</span>
              </div>
              <div className="flex gap-6 text-gray-500 text-sm">
                <a href="#" className="hover:text-emerald-400 transition-colors">About</a>
                <a href="#" className="hover:text-emerald-400 transition-colors">Privacy</a>
                <a href="#" className="hover:text-emerald-400 transition-colors">Terms</a>
                <a href="#" className="hover:text-emerald-400 transition-colors">Contact</a>
              </div>
              <p className="text-gray-600 text-sm">© 2026 AI Nexus. All rights reserved.</p>
            </div>
          </footer>
        </div>
      </main>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/generate" element={<GeneratePage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
