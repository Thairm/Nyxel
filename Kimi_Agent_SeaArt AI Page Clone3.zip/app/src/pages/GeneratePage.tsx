import { useState } from 'react';
import { 
  Sparkles, 
  Image, 
  Video, 
  AppWindow, 
  Bot, 
  Users, 
  Volume2, 
  MoreHorizontal,
  ChevronDown,
  Grid3X3,
  LayoutGrid,
  SlidersHorizontal,
  Maximize2,
  Download,
  Share2,
  MoreVertical,
  RotateCcw,
  FileText,
  Wand2,
  Zap,
  MessageSquare,
  ImagePlus,
  Info,
  Layers,
  LayoutTemplate
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Link } from 'react-router-dom';

// Navigation items for left sidebar with labels
const navItems = [
  { icon: Image, label: 'Image', active: true },
  { icon: Video, label: 'Video' },
  { icon: AppWindow, label: 'AI App' },
  { icon: Bot, label: 'Agent' },
  { icon: Users, label: 'Character' },
  { icon: Volume2, label: 'Audio' },
  { icon: MoreHorizontal, label: 'More' },
];

// Aspect ratio options
const aspectRatios = [
  { id: '2:3', label: '2:3', width: 40, height: 60 },
  { id: '1:1', label: '1:1', width: 40, height: 40 },
  { id: '9:16', label: '9:16', width: 30, height: 60 },
  { id: '4:3', label: '4:3', width: 50, height: 40 },
  { id: 'more', label: 'More', icon: Layers },
];

// Image quantity options
const quantityOptions = [1, 2, 3, 4];

// Sample generated images
const generatedImages = [
  { id: 1, src: '/gen-preview-1.jpg', width: 688, height: 1024 },
  { id: 2, src: '/gen-preview-2.jpg', width: 688, height: 1024 },
  { id: 3, src: '/gen-preview-3.jpg', width: 688, height: 1024 },
  { id: 4, src: '/gen-preview-4.jpg', width: 688, height: 1024 },
];

export default function GeneratePage() {
  const [generationMode, setGenerationMode] = useState<'standard' | 'quality'>('standard');
  const [selectedRatio, setSelectedRatio] = useState('2:3');
  const [imageQuantity, setImageQuantity] = useState(4);
  const [privateCreation, setPrivateCreation] = useState(false);
  const [freeCreation, setFreeCreation] = useState(true);
  const [advancedOpen, setAdvancedOpen] = useState(false);
  const [prompt, setPrompt] = useState('');
  const [activeTab, setActiveTab] = useState<'image' | 'video'>('image');

  return (
    <div className="min-h-screen bg-[#0D0F0E] flex">
      {/* Left Sidebar with Labels */}
      <aside className="w-16 bg-[#0D0F0E] border-r border-white/5 flex flex-col items-center py-4 fixed left-0 top-0 h-full z-50">
        {/* Logo */}
        <Link to="/" className="mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-emerald flex items-center justify-center">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
        </Link>

        {/* Navigation with Labels */}
        <nav className="flex-1 flex flex-col gap-1 w-full px-1">
          {navItems.map((item) => (
            <button
              key={item.label}
              className={`w-full flex flex-col items-center gap-0.5 py-2 rounded-xl transition-all duration-200 ${
                item.active 
                  ? 'bg-white/10 text-emerald-400' 
                  : 'text-gray-500 hover:text-white hover:bg-white/5'
              }`}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-[9px] font-medium">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* Bottom icons */}
        <div className="flex flex-col gap-2 w-full px-1">
          <button className="w-full flex flex-col items-center gap-0.5 py-2 rounded-xl text-gray-500 hover:text-white hover:bg-white/5 transition-all">
            <Zap className="w-5 h-5" />
            <span className="text-[9px] font-medium">106</span>
          </button>
          <button className="w-full flex flex-col items-center gap-0.5 py-2 rounded-xl text-gray-500 hover:text-white hover:bg-white/5 transition-all">
            <div className="w-5 h-5 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white text-[9px] font-bold">
              U
            </div>
            <span className="text-[9px] font-medium">1.0K</span>
          </button>
        </div>
      </aside>

      {/* Settings Panel - Wider and fills to bottom */}
      <div className="w-80 bg-[#141816] border-r border-white/5 ml-16 flex flex-col h-screen">
        {/* Image/Video Toggle - Above Model Selector */}
        <div className="p-4 border-b border-white/5">
          <div className="flex gap-1 bg-[#0D0F0E] rounded-lg p-1">
            <button
              onClick={() => setActiveTab('image')}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md text-sm font-medium transition-all ${
                activeTab === 'image'
                  ? 'bg-[#1A1E1C] text-white'
                  : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <Image className="w-4 h-4" />
              Image
            </button>
            <button
              onClick={() => setActiveTab('video')}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-md text-sm font-medium transition-all ${
                activeTab === 'video'
                  ? 'bg-[#1A1E1C] text-white'
                  : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <Video className="w-4 h-4" />
              Video
            </button>
          </div>
        </div>

        {/* Model Selector */}
        <div className="p-4 border-b border-white/5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-emerald-400 text-xs font-medium">Model</span>
            <button className="text-gray-500 hover:text-white">
              <Grid3X3 className="w-4 h-4" />
            </button>
          </div>
          <button className="w-full flex items-center justify-between p-3 bg-[#1A1E1C] rounded-xl border border-white/5 hover:border-emerald-500/30 transition-colors">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center">
                <Sparkles className="w-4 h-4 text-emerald-400" />
              </div>
              <div className="text-left">
                <p className="text-white text-sm font-medium">SeaArt-Infinity</p>
                <p className="text-gray-500 text-xs">v1.0</p>
              </div>
            </div>
            <ChevronDown className="w-4 h-4 text-gray-500" />
          </button>
          <button className="w-full mt-2 p-2.5 bg-[#1A1E1C] rounded-lg border border-white/5 text-gray-400 text-sm hover:text-white hover:border-white/10 transition-colors flex items-center justify-center gap-2">
            <LayoutTemplate className="w-4 h-4" />
            Combo Library
            <Badge className="bg-emerald-500/20 text-emerald-400 text-[10px] border-0 ml-1">NEW</Badge>
          </button>
        </div>

        {/* Scrollable Settings Area */}
        <div className="flex-1 overflow-y-auto scrollbar-thin">
          <div className="p-4 space-y-4">
            {/* Additional Section */}
            <div className="flex items-center justify-between">
              <span className="text-white text-sm font-medium">Additional</span>
              <button className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center">
                <Zap className="w-3 h-3 text-emerald-400" />
              </button>
            </div>

            {/* Basic Settings */}
            <div className="bg-[#1A1E1C] rounded-xl border border-white/5 overflow-hidden">
              <button className="w-full flex items-center justify-between p-3">
                <span className="text-white text-sm">Basic Settings</span>
                <ChevronDown className="w-4 h-4 text-gray-500" />
              </button>
              
              <div className="px-3 pb-3 space-y-4">
                {/* Generation Mode */}
                <div>
                  <div className="flex items-center gap-1 mb-2">
                    <span className="text-gray-400 text-xs">Generation Mode</span>
                    <Info className="w-3 h-3 text-gray-600" />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setGenerationMode('standard')}
                      className={`flex-1 py-2 px-3 rounded-lg text-xs font-medium transition-all ${
                        generationMode === 'standard'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-[#141816] text-gray-400 border border-white/5 hover:border-white/10'
                      }`}
                    >
                      Standard
                    </button>
                    <button
                      onClick={() => setGenerationMode('quality')}
                      className={`flex-1 py-2 px-3 rounded-lg text-xs font-medium transition-all flex items-center justify-center gap-1 ${
                        generationMode === 'quality'
                          ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          : 'bg-[#141816] text-gray-400 border border-white/5 hover:border-white/10'
                      }`}
                    >
                      <Zap className="w-3 h-3" />
                      Quality
                    </button>
                  </div>
                </div>

                {/* Image Settings */}
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-400 text-xs">Image Settings</span>
                    <span className="text-gray-600 text-xs">688 × 1024</span>
                  </div>
                  <div className="flex gap-2 overflow-x-auto scrollbar-thin pb-1">
                    {aspectRatios.map((ratio) => (
                      <button
                        key={ratio.id}
                        onClick={() => setSelectedRatio(ratio.id)}
                        className={`flex flex-col items-center gap-1 p-2 rounded-lg transition-all flex-shrink-0 ${
                          selectedRatio === ratio.id
                            ? 'bg-emerald-500/20 border border-emerald-500/30'
                            : 'bg-[#141816] border border-white/5 hover:border-white/10'
                        }`}
                      >
                        {ratio.icon ? (
                          <ratio.icon className="w-4 h-4 text-gray-400" />
                        ) : (
                          <div 
                            className={`border-2 rounded ${
                              selectedRatio === ratio.id ? 'border-emerald-400' : 'border-gray-500'
                            }`}
                            style={{ width: ratio.width, height: ratio.height }}
                          />
                        )}
                        <span className={`text-[10px] ${selectedRatio === ratio.id ? 'text-emerald-400' : 'text-gray-500'}`}>
                          {ratio.label}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Image Quantity */}
                <div>
                  <span className="text-gray-400 text-xs block mb-2">Image Quantity</span>
                  <div className="flex gap-2">
                    {quantityOptions.map((num) => (
                      <button
                        key={num}
                        onClick={() => setImageQuantity(num)}
                        className={`flex-1 py-2 rounded-lg text-xs font-medium transition-all ${
                          imageQuantity === num
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-[#141816] text-gray-400 border border-white/5 hover:border-white/10'
                        }`}
                      >
                        {num}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Private Creation Toggle */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <span className="text-gray-400 text-xs">Private Creation</span>
                    <Zap className="w-3 h-3 text-amber-400" />
                    <Info className="w-3 h-3 text-gray-600" />
                  </div>
                  <Switch 
                    checked={privateCreation} 
                    onCheckedChange={setPrivateCreation}
                    className="data-[state=checked]:bg-emerald-500"
                  />
                </div>

                {/* Free Creation Toggle */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1">
                    <span className="text-gray-400 text-xs">Free Creation</span>
                    <Zap className="w-3 h-3 text-amber-400" />
                    <Info className="w-3 h-3 text-gray-600" />
                  </div>
                  <Switch 
                    checked={freeCreation} 
                    onCheckedChange={setFreeCreation}
                    className="data-[state=checked]:bg-emerald-500"
                  />
                </div>
              </div>
            </div>

            {/* Advanced Config - Right above Reset/Notes */}
            <button 
              onClick={() => setAdvancedOpen(!advancedOpen)}
              className="w-full flex items-center justify-between p-3 bg-[#1A1E1C] rounded-xl border border-white/5 hover:border-white/10 transition-colors"
            >
              <span className="text-white text-sm">Advanced Config</span>
              <ChevronDown className={`w-4 h-4 text-gray-500 transition-transform ${advancedOpen ? 'rotate-180' : ''}`} />
            </button>
          </div>
        </div>

        {/* Bottom Actions - Always visible at bottom */}
        <div className="p-4 border-t border-white/5 flex gap-2 bg-[#141816]">
          <button className="flex-1 py-2.5 px-3 bg-[#1A1E1C] rounded-lg border border-white/5 text-gray-400 text-sm hover:text-white hover:border-white/10 transition-colors flex items-center justify-center gap-2">
            <RotateCcw className="w-4 h-4" />
            Reset
          </button>
          <button className="flex-1 py-2.5 px-3 bg-[#1A1E1C] rounded-lg border border-white/5 text-gray-400 text-sm hover:text-white hover:border-white/10 transition-colors flex items-center justify-center gap-2">
            <FileText className="w-4 h-4" />
            Notes
          </button>
        </div>
      </div>

      {/* Main Content Area - Side by side with no gap */}
      <main className="flex-1 ml-0 flex flex-col h-screen overflow-hidden">
        {/* Image Preview Area - Scrollable with scrollbar */}
        <div className="flex-1 overflow-y-auto scrollbar-thin p-6">
          {/* Top Toolbar */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Badge className="bg-emerald-500/20 text-emerald-400 border-0">Txt2Img</Badge>
              <span className="text-gray-400 text-sm truncate max-w-2xl">
                Enchanted forest landscape at twilight, giant ethereal mushrooms emitting soft neon light, a mysterious woodland creature with glowing antlers...
              </span>
            </div>
            <div className="flex items-center gap-2">
              <button className="w-8 h-8 rounded-lg bg-[#1A1E1C] border border-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:border-white/10 transition-colors">
                <LayoutGrid className="w-4 h-4" />
              </button>
              <button className="w-8 h-8 rounded-lg bg-[#1A1E1C] border border-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:border-white/10 transition-colors">
                <SlidersHorizontal className="w-4 h-4" />
              </button>
              <button className="w-8 h-8 rounded-lg bg-[#1A1E1C] border border-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:border-white/10 transition-colors">
                <Maximize2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Image Info Bar - MOVED TO TOP of generated images */}
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white text-xs font-bold">
                  S
                </div>
                <span className="text-gray-400 text-sm">SeaArt Infinity</span>
              </div>
              <div className="flex items-center gap-1 text-gray-500 text-sm">
                <Maximize2 className="w-3 h-3" />
                688 × 1024px
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-white transition-colors">
                <MessageSquare className="w-4 h-4" />
              </button>
              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-white transition-colors">
                <Info className="w-4 h-4" />
              </button>
              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-white transition-colors">
                <RotateCcw className="w-4 h-4" />
              </button>
              <button className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-white transition-colors">
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Generated Images Grid */}
          <div className="grid grid-cols-4 gap-4 mb-6">
            {generatedImages.map((image, index) => (
              <div key={image.id} className="relative group">
                <div className="relative rounded-xl overflow-hidden bg-[#1A1E1C] border border-white/5">
                  <img 
                    src={image.src} 
                    alt={`Generated ${index + 1}`}
                    className="w-full h-auto object-cover"
                  />
                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <button className="w-10 h-10 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/30 transition-colors">
                      <Download className="w-5 h-5" />
                    </button>
                    <button className="w-10 h-10 rounded-lg bg-white/20 backdrop-blur-sm flex items-center justify-center text-white hover:bg-white/30 transition-colors">
                      <Share2 className="w-5 h-5" />
                    </button>
                  </div>
                  {/* Image Number Badge */}
                  <div className="absolute top-2 right-2 w-6 h-6 rounded bg-black/60 flex items-center justify-center text-white text-xs font-medium">
                    {index + 1}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom Prompt Input Area */}
        <div className="p-4 border-t border-white/5 bg-[#0D0F0E]">
          <div className="max-w-5xl mx-auto">
            {/* Play It Button - Top left of prompt box */}
            <div className="mb-2">
              <button className="flex items-center gap-2 px-4 py-2 bg-[#1A1E1C] rounded-full border border-white/10 text-gray-300 hover:text-white hover:border-white/20 transition-colors text-sm">
                <Wand2 className="w-4 h-4" />
                Play It
              </button>
            </div>
            
            <div className="relative bg-[#1A1E1C] rounded-2xl border border-white/5 p-4">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="What do you want to create?"
                className="w-full bg-transparent text-white placeholder:text-gray-500 resize-none outline-none min-h-[50px] text-sm"
                rows={2}
              />
              <div className="flex items-center justify-between mt-2">
                <div className="flex items-center gap-2">
                  <button className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 transition-colors">
                    <ImagePlus className="w-4 h-4" />
                  </button>
                  <button className="w-8 h-8 rounded-lg flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/5 transition-colors">
                    <LayoutGrid className="w-4 h-4" />
                  </button>
                </div>
                <div className="flex items-center gap-3">
                  <button className="flex items-center gap-2 px-4 py-2 text-gray-400 hover:text-white transition-colors">
                    <MessageSquare className="w-4 h-4" />
                    <span className="text-sm">Assistant</span>
                  </button>
                  <button className="px-6 py-2 bg-gray-600 text-gray-300 rounded-full font-medium hover:bg-gray-500 transition-colors">
                    Generate
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Custom scrollbar styles */}
      <style>{`
        .scrollbar-thin::-webkit-scrollbar {
          width: 6px;
          height: 6px;
        }
        .scrollbar-thin::-webkit-scrollbar-track {
          background: transparent;
        }
        .scrollbar-thin::-webkit-scrollbar-thumb {
          background: #2A2E2C;
          border-radius: 3px;
        }
        .scrollbar-thin::-webkit-scrollbar-thumb:hover {
          background: #3A3E3C;
        }
        .scrollbar-thin::-webkit-scrollbar-corner {
          background: transparent;
        }
      `}</style>
    </div>
  );
}
